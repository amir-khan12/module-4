package com.cg.service;

import java.util.List;

import com.cg.bean.StockBean;
import com.cg.exception.ShareException;

public interface IServiceStock {
	public List<StockBean> retrieveAllStocks() throws ShareException;
	public StockBean displayStock(String stockName) throws ShareException;
}
