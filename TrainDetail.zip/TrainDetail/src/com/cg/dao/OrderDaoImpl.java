package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.OrderBean;
import com.cg.exception.ShareException;

@Repository
@Transactional
public class OrderDaoImpl implements IOrderDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addOrder(OrderBean oBean) throws ShareException {
		int id = 0;

		try {
			entityManager.persist(oBean);
			entityManager.flush();
			id= oBean.getOrderId();
		} catch (Exception e) {
			throw new ShareException("unable to persist in Dao Layer"
					+ e.getMessage());
		}

		return id;
	
	}

}
