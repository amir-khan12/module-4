package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.bean.TraineeBean;
import com.test.dao.AdminDaoImpl;
import com.test.dao.IAdminDao;
import com.test.dao.ITraineeDao;
import com.test.dao.TraineeDaoImpl;
import com.test.exception.TraineeException;

@Service
public class TraineeServieImpl implements ITraineeService {

	@Autowired
	ITraineeDao traineeDao = new TraineeDaoImpl();
	
	@Autowired
	IAdminDao adminDao = new AdminDaoImpl();
	
	TraineeBean beanDao = new TraineeBean();
	
	@Override
	public int addTrainer(TraineeBean traineeBean) throws TraineeException {
		
	
		return traineeDao.addTrainer(traineeBean);
		
	}

	@Override
	public void deleteTrainer(int id) throws TraineeException {
		traineeDao.deleteTrainer(id);
		
	}

	@Override
	public void updateTrainee(TraineeBean traineeBean) throws TraineeException {
		traineeDao.updateTrainee(traineeBean);
		
		
	}

	@Override
	public TraineeBean retriveTrainee(int id) throws TraineeException {
		
		return traineeDao.retriveTrainee(id);
	}

	@Override
	public List<TraineeBean> viewAll() throws TraineeException {
		return traineeDao.viewAll();
	}

	@Override
	public boolean isLogged(String username, String pass)
			throws TraineeException {
		
		return adminDao.isLogged(username, pass) ;
	}

}
