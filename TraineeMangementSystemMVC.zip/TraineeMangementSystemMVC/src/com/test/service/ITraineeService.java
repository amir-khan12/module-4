package com.test.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.test.bean.TraineeBean;
import com.test.dao.ITraineeDao;
import com.test.dao.TraineeDaoImpl;
import com.test.exception.TraineeException;

@Service
public interface ITraineeService {
	
	
	public int addTrainer(TraineeBean traineeBean) throws TraineeException;
	public void deleteTrainer(int id) throws TraineeException;
	public void updateTrainee(TraineeBean traineeBean) throws TraineeException;
	public TraineeBean retriveTrainee(int id) throws TraineeException;
	
	public List<TraineeBean> viewAll() throws TraineeException;
	
	public boolean isLogged(String username, String pass) throws TraineeException;

}
