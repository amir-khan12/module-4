package com.test.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



import com.test.bean.TraineeBean;
import com.test.exception.TraineeException;
import com.test.service.ITraineeService;
import com.test.service.TraineeServieImpl;

@Controller
public class testController 
{
	  @PersistenceContext
	  private EntityManager em;
	
	@Autowired
	ITraineeService traineeService = new TraineeServieImpl();
	
	
    @RequestMapping(value = "addTrainee" , method = RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") TraineeBean bean,
			BindingResult result)
			
	{
		
		int id = 0;
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed"+result.getAllErrors());
		}
		else
		{
			try {
				id = traineeService.addTrainer(bean);
				
				mv.setViewName("successAdd");
				mv.addObject("trainee", bean);
				
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
			
			
		}
		
		
		
		return (mv);
	}
  
  @RequestMapping(value = "deleteTrainee" , method = RequestMethod.GET)
  public ModelAndView removeTrainee(@RequestParam ("id") String id)
  {
	  
	  ModelAndView mv = new ModelAndView();
	  int traineeId = 0;
	  traineeId = Integer.parseInt(id);
	  
	  try {
		traineeService.deleteTrainer(traineeId);
		mv.setViewName("deleted");
		mv.addObject("id", traineeId);
		
	} catch (TraineeException e) {
		mv.setViewName("error");
		mv.addObject("message", e.getMessage());
	}
	  
	  
	  return mv;
	  
	  
  }
  
  @RequestMapping("updatePage")
  public ModelAndView updatePageDisplay(@RequestParam ("id") String id)
  {
	  ModelAndView mv = new ModelAndView();
	  int traineeId = Integer.parseInt(id);
	  
	  mv.setViewName("modifyPage");
	  mv.addObject("id", id);

	  
	  return mv;
  }
  
  @RequestMapping(value ="changeTrainee", method = RequestMethod.POST)
  public ModelAndView changeTraineeTbl(@ModelAttribute("trainee") TraineeBean bean,
			BindingResult result)

			{
		
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed"+result.getAllErrors());
		}
		else
		{
			try {
				traineeService.updateTrainee(bean);
				
				mv.setViewName("successUpdate");
				mv.addObject("trainee", bean);
				
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
			
			
		}
		
		return (mv);
			}
  
  @RequestMapping(value ="getTrainee", method = RequestMethod.POST)
  public ModelAndView retriveTrainee(@RequestParam ("id") String id)
  {
	  ModelAndView mv = new ModelAndView();
	  int traineeId = Integer.parseInt(id);
	  try {
		TraineeBean bean = traineeService.retriveTrainee(traineeId);
		mv.setViewName("successView");
		mv.addObject("trainee", bean);
	} catch (TraineeException e) {
		
		mv.setViewName("error");
		mv.addObject("message", e.getMessage());
	}
	

	  
	  return mv;
  }
  
  @RequestMapping("showAll")
	public ModelAndView viewAll()
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			List<TraineeBean> list = traineeService.viewAll();
			
			mv.setViewName("viewAll");
			mv.addObject("list", list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		return mv;
	}
  
  @RequestMapping(value = "login" , method = RequestMethod.POST)
  public ModelAndView login(@RequestParam ("username") String username, @RequestParam ("password") String pass)
  {
	  
	  ModelAndView mv = new ModelAndView();
	  boolean found = false;
	 try {
		found =  traineeService.isLogged(username, pass);
		if(found == true)
		{
			mv.setViewName("index");
		}
		else{
			mv.setViewName("loginPage");
			mv.addObject("message", "invalid loginId or Password");
		}
	} catch (TraineeException e) {
		mv.setViewName("error");
		mv.addObject("message", e.getMessage());
	}
	  
	  return mv;
  }
  
}
