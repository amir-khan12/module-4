package com.test.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.test.bean.AdminBean;
import com.test.exception.TraineeException;
@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao{

	@PersistenceContext
	EntityManager em;
	@Override
	public boolean isLogged(String username, String pass)
			throws TraineeException {
		boolean isLogged = false;
		
		AdminBean admin = em.find(AdminBean.class, username);
		if(admin!= null)
		{
			if(admin.getPass().equals(pass));
			{
				isLogged = true;
			}
		}
		return isLogged;
	}

}
