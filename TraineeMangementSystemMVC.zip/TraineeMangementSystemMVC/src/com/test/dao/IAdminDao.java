package com.test.dao;

import com.test.exception.TraineeException;

public interface IAdminDao {
	public boolean isLogged(String username, String pass) throws TraineeException;

}
