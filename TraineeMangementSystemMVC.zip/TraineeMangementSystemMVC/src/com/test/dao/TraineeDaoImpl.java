package com.test.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.test.bean.AdminBean;
import com.test.bean.TraineeBean;
import com.test.exception.TraineeException;

@Transactional
@Repository
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager em;
	@Override
	public int addTrainer(TraineeBean traineeBean) throws TraineeException {
		
		
		em.persist(traineeBean);
		em.flush();
		return traineeBean.getTraineeId();
	}
	@Override
	public void deleteTrainer(int id) throws TraineeException {
		
		TraineeBean bean = em.find(TraineeBean.class, id);
		em.remove(bean);
		
	}
	@Override
	public void updateTrainee(TraineeBean traineeBean) throws TraineeException {
		
		TraineeBean bean = em.find(TraineeBean.class, traineeBean.getTraineeId());
		
		em.remove(bean);
		em.persist(traineeBean);
		
	}
	@Override
	public TraineeBean retriveTrainee(int id) throws TraineeException {
		TraineeBean bean = em.find(TraineeBean.class, id);
		
		return bean;
		
	}
	@Override
	public List<TraineeBean> viewAll() throws TraineeException {
		List<TraineeBean> list = null;
		try {
			TypedQuery<TraineeBean> query = em.createQuery("select e from TraineeBean e", TraineeBean.class);
			
			list = query.getResultList();
		} catch (Exception e) {
			throw new TraineeException("unable to fetch records"+e.getMessage());
		}
		
		return list;
		
	}
	

}
