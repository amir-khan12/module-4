package com.test.dao;


import java.sql.SQLException;
import java.util.List;

import com.test.bean.TraineeBean;
import com.test.exception.TraineeException;
public interface ITraineeDao {
	
	public int addTrainer(TraineeBean traineeBean) throws TraineeException ;
	public void deleteTrainer(int id) throws TraineeException;
	public void updateTrainee(TraineeBean traineeBean) throws TraineeException;
	public TraineeBean retriveTrainee(int id) throws TraineeException;
	public List<TraineeBean> viewAll() throws TraineeException;
	

	
	

}
