package com.test.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.test.bean.SessionBean;
import com.test.exception.SessionException;

@Repository
@Transactional
public class SessionDAOImpl implements ISessionDAO {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public List<SessionBean> viewAll() throws SessionException {
		
		List<SessionBean> list = null;
		try {
			TypedQuery<SessionBean> query = em.createQuery("select e from SessionBean e", SessionBean.class);
			
			list = query.getResultList();
		} catch (Exception e) {
			throw new SessionException("Unable to fetch records"+e.getMessage());
		}
		
		return list;
		
	}

	@Override
	public void updateTrainee(SessionBean sessionBean) throws SessionException {
		
	}

}
