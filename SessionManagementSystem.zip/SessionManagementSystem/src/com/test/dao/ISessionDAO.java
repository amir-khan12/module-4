package com.test.dao;

import java.util.List;

import com.test.bean.SessionBean;
import com.test.exception.SessionException;




public interface ISessionDAO {
	
	public List<SessionBean> viewAll() throws SessionException;
	public void updateTrainee(SessionBean sessionBean) throws SessionException;

}
