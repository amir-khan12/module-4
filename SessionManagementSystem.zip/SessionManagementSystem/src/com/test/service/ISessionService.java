package com.test.service;

import java.util.List;

import com.test.bean.SessionBean;
import com.test.exception.SessionException;

public interface ISessionService {
	
	public List<SessionBean> viewAll() throws SessionException;
	public void updateTrainee(SessionBean sessionBean) throws SessionException;

}
