package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.test.bean.SessionBean;
import com.test.dao.ISessionDAO;
import com.test.dao.SessionDAOImpl;
import com.test.exception.SessionException;

public class SessionServiceImpl implements ISessionDAO {
	@Autowired
	ISessionDAO sessionDao = new SessionDAOImpl();

	@Override
	public List<SessionBean> viewAll() throws SessionException {
		return sessionDao.viewAll();
	
	}

	@Override
	public void updateTrainee(SessionBean sessionBean) throws SessionException {
		sessionDao.updateTrainee(sessionBean);
	}

}
