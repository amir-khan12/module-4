package com.test.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ScheduledSessions")
public class SessionBean {
	@Id
	@Column(name="Id")
	private int sessionId;
	@Column(name="name" , length=20)
	private String sessionName;
	@Column(name="duration")
	private int sessionDuration;
	@Column(name="faculty")
	private String sesssionFaculty;
	@Column(name="mode")
	private String mode;
	public SessionBean() {
		super();
	}
	public SessionBean(int sessionId, String sessionName, int sessionDuration, String sesssionFaculty, String mode) {
		super();
		this.sessionId = sessionId;
		this.sessionName = sessionName;
		this.sessionDuration = sessionDuration;
		this.sesssionFaculty = sesssionFaculty;
		this.mode = mode;
	}
	public int getSessionId() {
		return sessionId;
	}
	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public int getSessionDuration() {
		return sessionDuration;
	}
	public void setSessionDuration(int sessionDuration) {
		this.sessionDuration = sessionDuration;
	}
	public String getSesssionFaculty() {
		return sesssionFaculty;
	}
	public void setSesssionFaculty(String sesssionFaculty) {
		this.sesssionFaculty = sesssionFaculty;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	
	

}
